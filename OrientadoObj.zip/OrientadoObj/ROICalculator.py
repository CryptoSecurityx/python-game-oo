class ROI:

    def __init__(self,valor_investido,Valor_Parcelado,Renda_mensal,Retorno_Invest):

        self.valor_investido = valor_investido
        self.Valor_Parcelado = Valor_Parcelado
        self.Retorno_Invest = Retorno_Invest
        self.Renda_mensal = Renda_mensal

    def calcular(self, input_investido):
        valor_Parcelado = self.input_investido / 12
        Renda_Mensal = 488.43  ### 488.43 ###
        i = 1
        contador = 0

        for i in contador:
            i = contador + 1
            formula = self.input_investido * i

            if formula == self.input_investido:
                self.Retorno_Invest = i
                return self.Retorno_Invest










