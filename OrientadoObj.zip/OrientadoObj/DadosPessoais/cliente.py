class Cliente:
    def __init__(self,usuario,nome,senha,celular,cpf,idade):

        self.usuario = usuario
        self.nome  = nome
        self.senha = senha
        self.celular = celular
        self.cpf = cpf
        self.idade = idade


    def alterarSenha(self, senha):
        self.senha = senha







